import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { WebView } from 'react-native-webview';
import { useTheme } from '../theme/ThemeContext';

const EpubReader = forwardRef(function EpubReader(
  {
    uri,
    startCfi,
    onProgress,
    onToggleChrome,
    fontFamily,
    flow = 'paginated',
    direction = 'ltr',
  },
  ref,
) {
  const { colors } = useTheme();
  const styles = getStyles(colors);
  const webRef = useRef(null);
  const [loadError, setLoadError] = useState(null);
  const [renditionReady, setRenditionReady] = useState(false);

  useImperativeHandle(ref, () => ({
    seekTo({ percent, cfi }) {
      webRef.current?.postMessage(
        JSON.stringify({ type: 'seek', payload: { percent, cfi } }),
      );
    },
  }));

  function sendTheme() {
    webRef.current?.postMessage(
      JSON.stringify({
        type: 'theme',
        payload: {
          bg: colors.readerBg,
          text: colors.readerText,
          fontFamily: fontFamily || undefined,
        },
      }),
    );
  }

  function handleMessage(event) {
    const msg = JSON.parse(event.nativeEvent.data);
    if (msg.type === 'progress')
      onProgress(msg.payload.percent || 0, msg.payload.cfi);
    if (msg.type === 'toggleChrome') onToggleChrome();
    if (msg.type === 'loadError') {
      setLoadError(msg.payload.message);
    }
    if (msg.type === 'ready') {
      setRenditionReady(true);
    }
  }

  useEffect(() => {
    if (renditionReady) sendTheme();
  }, [renditionReady, colors.readerBg, colors.readerText, fontFamily]);

  const htmlUri = `file:///android_asset/epub-reader.html?src=${encodeURIComponent(
    'file://' + uri,
  )}${
    startCfi ? `&cfi=${encodeURIComponent(startCfi)}` : ''
  }&flow=${flow}&direction=${direction}`;

  if (loadError) {
    return (
      <View style={styles.loading}>
        <Text style={{ color: colors.text, textAlign: 'center', padding: 16 }}>
          Couldn't open this book.{'\n'}
          {loadError}
        </Text>
      </View>
    );
  }
  return (
    <View style={styles.fill}>
      <WebView
        ref={webRef}
        originWhitelist={['*']}
        source={{ uri: htmlUri }}
        onMessage={handleMessage}
        javaScriptEnabled
        domStorageEnabled
        allowFileAccess
        allowFileAccessFromFileURLs
        allowUniversalAccessFromFileURLs
        style={styles.fill}
      />
    </View>
  );
});

export default EpubReader;

const getStyles = colors =>
  StyleSheet.create({
    fill: { flex: 1, backgroundColor: colors.bg },
  });
